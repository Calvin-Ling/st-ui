import { css } from 'lit';

export default css`
  :host {
    display: inline-block;
  }
`;
