export { getAnimationNames, getEasingNames } from '../components/animation/animations.js';
