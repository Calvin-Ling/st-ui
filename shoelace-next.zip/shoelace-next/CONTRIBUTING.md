# Contributing to Shoelace

Before contributing, please review the contributions guidelines at:

[shoelace.style/resources/contributing](https://shoelace.style/resources/contributing)
