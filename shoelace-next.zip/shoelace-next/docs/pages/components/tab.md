---
meta:
  title: Tab
  description: Tabs are used inside tab groups to represent and activate tab panels.
layout: component
---

:::tip
Additional demonstrations can be found in the [tab group examples](/components/tab-group).
:::
