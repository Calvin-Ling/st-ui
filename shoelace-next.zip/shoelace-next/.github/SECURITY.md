# Reporting Security Issues

We take security issues in Shoelace very seriously and appreciate your efforts to disclose your findings responsibly.

To report a security issue, email [cory@abeautifulsite.net](mailto:cory@abeautifulsite.net) and include "SHOELACE SECURITY" in the subject line.

We'll respond as soon as possible and keep you updated throughout the process.
